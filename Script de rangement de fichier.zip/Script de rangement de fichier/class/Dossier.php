<?php 
	function tronque($name)
{
	$last_space = strrpos($name, "-");
	$name = substr($name, 0, $last_space);
	return $name;
}



	class Dossier 
	{
		public $source;
		public $dest;
		
		
		public function __construct($init_source,$init_dest)
		{
			
				$this->source = $init_source;
				$this->dest = $init_dest;
		}

		public function listfile()
		{

			if ($handle = opendir($this->source)) {
				while (false !== ($entry = readdir($handle))) 
				{

					var_dump($entry);
					if($entry != "." and $entry != "..")
						$list[] = $entry;
				
				}
			}
			closedir($handle);
			return $list;
		}

		public function createRepository($list)
		{
			
			foreach ($list as $list)
			 {
				if (!is_dir($list))
				 {
				 	$repository=tronque($list);
					mkdir($repository);
				
				//DEPLACEMENT DES FICHIERS
					$src=$this->source."\\".$list;
					$dest=$this->dest."\\".$repository."\\".$list;
					if (!file_exists($list)) {

						

						copy($src, $dest);
						unlink($src);
						echo "success";
					}

				}
			}
		}

		

	}

 ?>