
<?php 

require('class/Dossier.php');

 $source="C:\wamp\www\devoir php avancé\img";
$dest="C:\wamp\www\devoir php avancé";

 $dossier = new Dossier($source,$dest);

	 $list=$dossier->listfile();
	$dossier->createRepository($list);


 ?>



